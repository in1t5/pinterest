// Pins 25–28 — Newspaper, Planner, Bauhaus Grid, Certificate

const LOGO_G = 'assets/logo_framed.png';

function EyebrowG({ children, dotColor }) {
  return (
    <span className="eyebrow">
      <span className="dot" style={dotColor ? { background: dotColor } : null}></span>
      <span>{children}</span>
    </span>
  );
}
function FooterBrandG() {
  return (
    <div className="footer-brand">
      <img src={LOGO_G} alt="" />
      <div>
        <div className="name">Time &amp; Moneytree</div>
        <div className="url">TIMEANDMONEYTREE.COM</div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 25 — Newspaper Front Page
// ─────────────────────────────────────────────────────────────────────────
function Pin25() {
  return (
    <div className="pin pin-25">
      <div className="paper"></div>

      <div className="masthead">
        <div className="title">The Money <em>Tree</em></div>
        <div className="meta-bar">
          <span>Vol. XII · No. 47</span>
          <span className="center">— a calmer financial weekly —</span>
          <span>Free Edition · 2026</span>
        </div>
      </div>

      <div className="lead">
        <div className="kicker">Personal Finance · Calculators</div>
        <h1>
          Family of five<br />
          retires at <em>forty-four</em>,<br />
          owes nothing to anyone.
        </h1>
        <div className="byline">By the numbers · with our free FIRE calculator</div>
      </div>

      <div className="body">
        <div className="col">
          They started with an embarrassingly normal salary, a 22-year mortgage, and a working assumption that retirement was a lottery ticket. Eleven years later they are no longer interested in either.
        </div>
        <div className="col">
          The trick was not earning more. It was paying themselves first, every month, into a single index fund — and then not touching it. Boring, mechanical, devastatingly effective over a decade.
        </div>
        <div className="col">
          You can run the same plan against your own numbers in about sixty seconds. We built the calculator that turns a savings rate into an honest retirement date and stress-tests it from there.
        </div>
      </div>

      <div className="pullquote">
        We didn't beat the market. We just stopped fighting time.
      </div>

      <div className="footer">
        <FooterBrandG />
        <span className="cta-pill">Read the calculator →</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 26 — Planner Page
// ─────────────────────────────────────────────────────────────────────────
function Pin26() {
  return (
    <div className="pin pin-26">
      <div className="grid-paper"></div>
      <div className="punch-holes">
        <div className="h"></div>
        <div className="h"></div>
        <div className="h"></div>
        <div className="h"></div>
        <div className="h"></div>
        <div className="h"></div>
      </div>
      <div className="red-margin"></div>

      <div className="top">
        <span className="date">Sunday · April 14, 2026</span>
        <span className="week">Week 15 · Money Ritual</span>
      </div>

      <h1 className="headline">
        A fifteen-minute<br />
        <em>Sunday ritual</em><br />
        that runs our money.
      </h1>

      <div className="handwritten">do these five</div>

      <div className="checklist">
        <div className="check done">
          <span className="box"></span>
          <span className="label">Move €420 into the ETF.</span>
          <span className="amt">automated · 4 min</span>
        </div>
        <div className="check done">
          <span className="box"></span>
          <span className="label">Log this week's spend.</span>
          <span className="amt">€538.20</span>
        </div>
        <div className="check done">
          <span className="box"></span>
          <span className="label">Cancel one subscription.</span>
          <span className="amt">−€11.99 / mo</span>
        </div>
        <div className="check">
          <span className="box"></span>
          <span className="label">Top up the buffer to 6mo.</span>
          <span className="amt">€14,040 target</span>
        </div>
        <div className="check">
          <span className="box"></span>
          <span className="label">Update the FI calculator.</span>
          <span className="amt">142 → 138 months</span>
        </div>
      </div>

      <svg className="doodle" viewBox="0 0 160 100" fill="none">
        <path d="M 10 80 Q 50 30 80 50 T 150 20" stroke="#F1683F" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M 140 30 L 150 20 L 144 32" stroke="#F1683F" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
        <circle cx="10" cy="80" r="4" fill="#F1683F" />
        <text x="20" y="92" fontFamily="Pinyon Script, cursive" fontSize="24" fill="#47584F">growth :)</text>
      </svg>

      <div className="footer">
        <FooterBrandG />
        <span className="cta-pill">Get the worksheet →</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 27 — Bauhaus Grid
// ─────────────────────────────────────────────────────────────────────────
function Pin27() {
  return (
    <div className="pin pin-27">
      <div className="grid">
        <div className="blk b1">
          <EyebrowG dotColor="#C1D5A5">FIRE Calculator</EyebrowG>
          <h1>
            Three<br />
            numbers,<br />
            <em>one date.</em>
          </h1>
          <div className="deck">
            The whole calculator. A salary, a spend, a savings rate. Everything else is decoration.
          </div>
        </div>

        <div className="blk b2">
          <div className="lbl">Save rate</div>
          <div className="val">38<em>%</em></div>
          <div className="sub">of take-home, monthly</div>
        </div>

        <div className="blk b3">
          <div className="lbl">FI age</div>
          <div className="val">44</div>
          <div className="sub">years from today · 13.2</div>
        </div>

        <div className="blk b4">
          <div className="lbl">FI number</div>
          <div className="val">€720K</div>
          <div className="sub">spend × 25</div>
        </div>

        <div className="blk b5">
          <div className="circle"></div>
        </div>

        <div className="blk b6">
          <div className="lbl">Real return</div>
          <div className="val">7<em>%</em></div>
          <div className="sub">conservative assumption</div>
        </div>

        <div className="blk b7">
          <div className="seg">
            <div className="lbl">Monthly contribution</div>
            <div className="val">€1,820</div>
          </div>
          <div className="seg">
            <div className="lbl">Annual spend</div>
            <div className="val">€28,800</div>
          </div>
          <div className="seg">
            <div className="lbl">Withdrawal rate</div>
            <div className="val">4%</div>
          </div>
        </div>
      </div>

      <div className="footer">
        <FooterBrandG />
        <span className="cta-pill">Run the calculator →</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 28 — Certificate / Diploma
// ─────────────────────────────────────────────────────────────────────────
function CornerOrnament() {
  return (
    <svg viewBox="0 0 80 80" fill="none">
      <path d="M 10 70 L 10 10 L 70 10" stroke="#47584F" strokeWidth="1.5" />
      <path d="M 20 25 Q 30 15 40 25 Q 30 35 20 25 Z" fill="#F1683F" opacity="0.85" />
      <circle cx="50" cy="20" r="4" fill="#47584F" />
      <path d="M 15 40 L 25 40 M 20 35 L 20 45" stroke="#84A17C" strokeWidth="1.5" />
    </svg>
  );
}

function Pin28() {
  return (
    <div className="pin pin-28">
      <div className="frame">
        <div className="corner tl"><CornerOrnament /></div>
        <div className="corner tr"><CornerOrnament /></div>
        <div className="corner bl"><CornerOrnament /></div>
        <div className="corner br"><CornerOrnament /></div>

        <div className="crest">
          <img src={LOGO_G} alt="" />
        </div>
        <div className="crest-line">Certificate of Financial Independence</div>

        <div className="award-line">
          This calculator is hereby awarded to
        </div>

        <div className="recipient">Future You</div>
        <div className="recipient-rule"></div>
        <div className="recipient-sub">recipient · class of 2037</div>

        <div className="citation">
          In recognition of <strong>thirteen years</strong> of unglamorous,
          uninterrupted, automatic monthly contributions — and the
          courage required to do nothing at all.
        </div>

        <div className="badges">
          <div className="badge">
            <div className="v">€720K</div>
            <div className="l">FI Number</div>
          </div>
          <div className="seal">Awarded<br />in your<br />44th year</div>
          <div className="badge">
            <div className="v">38%</div>
            <div className="l">Savings Rate</div>
          </div>
        </div>
      </div>

      <div className="footer">
        <FooterBrandG />
        <span className="cta-pill">Mint your certificate →</span>
      </div>
    </div>
  );
}

window.Pin25 = Pin25;
window.Pin26 = Pin26;
window.Pin27 = Pin27;
window.Pin28 = Pin28;
