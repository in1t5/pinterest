// Pins 13–16 — Modern / Professional templates

const LOGO_M2 = 'assets/logo_framed.png';

function EyebrowM2({ children, dotColor }) {
  return (
    <span className="eyebrow">
      <span className="dot" style={dotColor ? { background: dotColor } : null}></span>
      <span>{children}</span>
    </span>
  );
}
function FooterBrandM2() {
  return (
    <div className="footer-brand">
      <img src={LOGO_M2} alt="" />
      <div>
        <div className="name">Time &amp; Moneytree</div>
        <div className="url">TIMEANDMONEYTREE.COM</div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 13 — Retirement Probability · Gauge
// ─────────────────────────────────────────────────────────────────────────
function ProbabilityGauge({ pct = 94 }) {
  // 3/4 arc gauge — open at the bottom
  const cx = 250, cy = 250, r = 200;
  const startA = 135; // degrees
  const endA = 45;    // (wraps around the top)
  const sweep = 270;  // total visible arc
  const filled = (pct / 100) * sweep;

  const polar = (a) => {
    const rad = (a - 90) * Math.PI / 180;
    return [cx + r * Math.cos(rad), cy + r * Math.sin(rad)];
  };
  // arc from startA going clockwise by `len` degrees
  const arcPath = (len) => {
    const [x1, y1] = polar(startA);
    const [x2, y2] = polar(startA + len);
    const largeArc = len > 180 ? 1 : 0;
    return `M ${x1.toFixed(1)} ${y1.toFixed(1)} A ${r} ${r} 0 ${largeArc} 1 ${x2.toFixed(1)} ${y2.toFixed(1)}`;
  };

  // tick marks at 0, 25, 50, 75, 100%
  const ticks = [0, 25, 50, 75, 100].map((t) => {
    const a = startA + (t / 100) * sweep;
    const [x1, y1] = polar(a);
    const rad = (a - 90) * Math.PI / 180;
    const rOuter = r + 14;
    const x2 = cx + rOuter * Math.cos(rad);
    const y2 = cy + rOuter * Math.sin(rad);
    const rLabel = r + 32;
    const lx = cx + rLabel * Math.cos(rad);
    const ly = cy + rLabel * Math.sin(rad) + 4;
    return { t, x1, y1, x2, y2, lx, ly };
  });

  return (
    <svg viewBox="0 0 500 500">
      {/* base track */}
      <path d={arcPath(sweep)} fill="none"
            stroke="rgba(193,213,165,0.18)" strokeWidth="22" strokeLinecap="round" />
      {/* filled */}
      <path d={arcPath(filled)} fill="none"
            stroke="#26C6DA" strokeWidth="22" strokeLinecap="round" />
      {/* tick marks */}
      {ticks.map(({ t, x1, y1, x2, y2, lx, ly }) => (
        <g key={t}>
          <line x1={x1} y1={y1} x2={x2} y2={y2}
                stroke="rgba(245,238,237,0.35)" strokeWidth="1.5" />
          <text x={lx} y={ly} textAnchor="middle"
                fontFamily="Lato, sans-serif" fontSize="11" fontWeight="700"
                letterSpacing="0.16em" fill="rgba(245,238,237,0.55)">{t}</text>
        </g>
      ))}
    </svg>
  );
}

function Pin13() {
  return (
    <div className="pin pin-13">
      <div className="grain"></div>
      <div className="top">
        <EyebrowM2 dotColor="#26C6DA">Withdrawal Calculator · Monte Carlo</EyebrowM2>
        <div className="meta">
          1,000 simulations<br />
          Real S&amp;P 500 data
        </div>
      </div>

      <h1 className="headline">
        Will your money <em>last</em>?<br />
        Probability, not optimism.
      </h1>

      <div className="gauge-wrap">
        <ProbabilityGauge pct={94} />
      </div>
      <div className="gauge-pct">94<sup>%</sup></div>
      <div className="gauge-label">Probability of success · 40 years</div>

      <div className="scenario-row">
        <div className="scell">
          <div className="lbl">Portfolio</div>
          <div className="val">€820K</div>
        </div>
        <div className="scell">
          <div className="lbl">Withdrawal</div>
          <div className="val">€32K/yr</div>
        </div>
        <div className="scell">
          <div className="lbl">Strategy</div>
          <div className="val">4% Rule</div>
        </div>
        <div className="scell">
          <div className="lbl">Horizon</div>
          <div className="val">40 yrs</div>
        </div>
      </div>

      <div className="deck">
        Run your plan against a thousand historical paths. See which scenarios
        survive, which run dry, and which years are the riskiest to start in.
      </div>

      <div className="footer">
        <FooterBrandM2 />
        <span className="cta-pill">Stress-test your plan →</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 14 — Numbered Steps · 3-step explainer
// ─────────────────────────────────────────────────────────────────────────
function Pin14() {
  return (
    <div className="pin pin-14">
      <div className="top">
        <EyebrowM2>Free FIRE Calculator</EyebrowM2>
      </div>
      <h1 className="headline">
        Know your retirement date in <em>three steps.</em>
      </h1>
      <div className="deck">
        No spreadsheet. No advisor. No login. Three honest numbers and the
        rest is just arithmetic.
      </div>

      <div className="steps">
        <div className="step">
          <div className="nbox">i</div>
          <div className="body">
            <div className="title">Tell us what you spend.</div>
            <div className="desc">
              Not what you earn. Your real monthly cost of living — the most
              important number in any retirement plan.
            </div>
          </div>
          <div className="tag">€2,340<em>per month</em></div>
        </div>

        <div className="step">
          <div className="nbox">ii</div>
          <div className="body">
            <div className="title">Tell us what you save.</div>
            <div className="desc">
              Across pension, ISA, brokerage, side income — every euro headed
              toward future-you, every month.
            </div>
          </div>
          <div className="tag">€1,820<em>per month</em></div>
        </div>

        <div className="step">
          <div className="nbox">iii</div>
          <div className="body">
            <div className="title">See your date.</div>
            <div className="desc">
              Built on a 7% real return and the 4% rule — the same assumptions
              used by every credible FI study since 1998.
            </div>
          </div>
          <div className="tag">14.3 yrs<em>to freedom</em></div>
        </div>
      </div>

      <div className="footer">
        <FooterBrandM2 />
        <span className="cta-pill">Start step 1 →</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 15 — Money in one screen · 2x2 KPI grid
// ─────────────────────────────────────────────────────────────────────────
function Sparkline({ data, color = '#84A17C' }) {
  const W = 100, H = 32;
  const max = Math.max(...data), min = Math.min(...data);
  const norm = (v) => (max === min ? H / 2 : H - ((v - min) / (max - min)) * H);
  const d = data.map((v, i) => `${i === 0 ? 'M' : 'L'} ${(i / (data.length - 1) * W).toFixed(1)} ${norm(v).toFixed(1)}`).join(' ');
  return (
    <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none"
         style={{ width: '100%', height: 32, display: 'block' }}>
      <path d={d} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

function Pin15() {
  return (
    <div className="pin pin-15">
      <div className="topband">
        <EyebrowM2 dotColor="#26C6DA">Personal Finance Dashboard</EyebrowM2>
        <h1>
          Your whole money,<br />
          <em>on one quiet screen.</em>
        </h1>
        <div className="deck">
          Four numbers we check every Sunday — nothing else.
        </div>
      </div>

      <div className="grid">
        <div className="tile">
          <div className="head">
            <span className="lbl">Net Worth</span>
            <svg className="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
              <path d="M3 17 L9 11 L13 15 L21 7" />
              <path d="M14 7 L21 7 L21 14" />
            </svg>
          </div>
          <div>
            <div className="val">€128K</div>
            <div className="sub"><strong>+ €1,840</strong> this month</div>
          </div>
          <Sparkline data={[20,28,32,40,52,60,72,84,96,108,118,128]} />
        </div>

        <div className="tile">
          <div className="head">
            <span className="lbl">Savings Rate</span>
            <svg className="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="9" />
              <path d="M12 7 V12 L15 14" />
            </svg>
          </div>
          <div>
            <div className="val">38<span style={{ fontSize: 36, marginLeft: 4 }}>%</span></div>
            <div className="sub"><strong>+ 4 pts</strong> vs last year</div>
          </div>
          <Sparkline data={[22,24,26,28,30,30,32,34,34,36,37,38]} color="#3A5477" />
        </div>

        <div className="tile">
          <div className="head">
            <span className="lbl">Months to FI</span>
            <svg className="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="5" width="18" height="16" rx="2" />
              <path d="M16 3 V7 M8 3 V7 M3 11 H21" />
            </svg>
          </div>
          <div>
            <div className="val accent">142</div>
            <div className="sub"><strong>− 8 months</strong> since January</div>
          </div>
          <Sparkline data={[180,176,170,168,162,160,156,154,150,148,144,142]} color="#F1683F" />
        </div>

        <div className="tile">
          <div className="head">
            <span className="lbl">Monthly Spend</span>
            <svg className="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
              <path d="M4 7 H20 M4 12 H20 M4 17 H14" />
            </svg>
          </div>
          <div>
            <div className="val">€2,340</div>
            <div className="sub"><strong>− €110</strong> vs 12-mo avg</div>
          </div>
          <Sparkline data={[2580,2620,2510,2490,2460,2520,2480,2440,2410,2380,2360,2340]} color="#6E686A" />
        </div>
      </div>

      <div className="footer">
        <FooterBrandM2 />
        <span className="cta-pill">Build yours →</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 16 — Bold Question · Minimal
// ─────────────────────────────────────────────────────────────────────────
function Pin16() {
  return (
    <div className="pin pin-16">
      <div className="grain"></div>
      <div className="top">
        <EyebrowM2 dotColor="#C1D5A5">FI Number Calculator</EyebrowM2>
        <span className="tag">— a deceptively simple question —</span>
      </div>

      <div className="question">
        What's<br />
        <em>enough?</em>
      </div>

      <div className="answer-card">
        <div className="left">
          <div className="lbl">For your household</div>
          <div className="val">
            €<em>702,000</em>
          </div>
          <div className="sub">
            Based on €2,340/mo · 4% withdrawal · adjusted for inflation
          </div>
        </div>
        <div className="right">
          <span className="calculate">
            Calculate yours
            <span className="arrow">→</span>
          </span>
        </div>
      </div>

      <div className="footer-line"></div>

      <div className="footer">
        <FooterBrandM2 />
        <span className="footer-tagline">enough is a number, not a feeling.</span>
      </div>
    </div>
  );
}

window.Pin13 = Pin13;
window.Pin14 = Pin14;
window.Pin15 = Pin15;
window.Pin16 = Pin16;
