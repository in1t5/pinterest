// Pins 9–12 — Modern / Professional templates

const LOGO_M = 'assets/logo_framed.png';

function EyebrowM({ children, dotColor }) {
  return (
    <span className="eyebrow">
      <span className="dot" style={dotColor ? { background: dotColor } : null}></span>
      <span>{children}</span>
    </span>
  );
}
function FooterBrandM() {
  return (
    <div className="footer-brand">
      <img src={LOGO_M} alt="" />
      <div>
        <div className="name">Time &amp; Moneytree</div>
        <div className="url">TIMEANDMONEYTREE.COM</div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 9 — Compound Interest · Chart Hero
// ─────────────────────────────────────────────────────────────────────────
function CompoundChart() {
  // Two series — savings (linear) vs invested (compound). Both over 30 years.
  const W = 800, H = 380, PAD_L = 40, PAD_R = 16, PAD_T = 20, PAD_B = 36;
  const innerW = W - PAD_L - PAD_R;
  const innerH = H - PAD_T - PAD_B;
  const years = 30;
  const monthly = 200;
  const rate = 0.07;

  // Savings: principal + months*monthly
  const savings = [];
  for (let y = 0; y <= years; y++) {
    savings.push(5000 + y * 12 * monthly);
  }
  // Investing: future value w/ monthly comp
  const invested = [];
  const m = rate / 12;
  for (let y = 0; y <= years; y++) {
    const months = y * 12;
    const fvP = 5000 * Math.pow(1 + m, months);
    const fvC = monthly * ((Math.pow(1 + m, months) - 1) / m);
    invested.push(fvP + fvC);
  }
  const maxY = Math.max(...invested);
  const xScale = (i) => PAD_L + (i / years) * innerW;
  const yScale = (v) => PAD_T + innerH - (v / maxY) * innerH;

  const toPath = (arr) =>
    arr.map((v, i) => `${i === 0 ? 'M' : 'L'} ${xScale(i).toFixed(1)} ${yScale(v).toFixed(1)}`).join(' ');
  const toArea = (arr) =>
    `${toPath(arr)} L ${xScale(years).toFixed(1)} ${(PAD_T + innerH).toFixed(1)} L ${PAD_L} ${(PAD_T + innerH).toFixed(1)} Z`;

  const fmt = (n) => '€' + Math.round(n / 1000) + 'K';

  return (
    <svg className="chart-svg" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
      {/* horizontal gridlines */}
      {[0, 0.25, 0.5, 0.75, 1].map((t, i) => (
        <g key={i}>
          <line x1={PAD_L} x2={W - PAD_R}
                y1={PAD_T + innerH * (1 - t)} y2={PAD_T + innerH * (1 - t)}
                stroke="#EAEDCE" strokeWidth="1" />
          <text x={PAD_L - 8} y={PAD_T + innerH * (1 - t) + 4}
                textAnchor="end" fontSize="10" fill="#9A9693"
                fontFamily="Lato, sans-serif" fontWeight="700"
                letterSpacing="0.08em">{fmt(maxY * t)}</text>
        </g>
      ))}

      {/* invested area */}
      <path d={toArea(invested)} fill="rgba(58,84,119,0.10)" />
      {/* savings area */}
      <path d={toArea(savings)} fill="rgba(110,104,106,0.06)" />

      {/* savings line */}
      <path d={toPath(savings)} fill="none" stroke="#6E686A"
            strokeWidth="2" strokeDasharray="6 4" />
      {/* invested line */}
      <path d={toPath(invested)} fill="none" stroke="#3A5477" strokeWidth="3" />

      {/* end markers */}
      <circle cx={xScale(years)} cy={yScale(savings[years])} r="4" fill="#6E686A" />
      <circle cx={xScale(years)} cy={yScale(invested[years])} r="6"
              fill="#F1683F" stroke="#fff" strokeWidth="2" />

      {/* x-axis labels */}
      {[0, 10, 20, 30].map((y) => (
        <text key={y} x={xScale(y)} y={H - 14}
              textAnchor="middle" fontSize="10" fill="#9A9693"
              fontFamily="Lato, sans-serif" fontWeight="700"
              letterSpacing="0.12em">Y{y}</text>
      ))}
    </svg>
  );
}

function Pin9() {
  return (
    <div className="pin pin-9">
      <div className="top">
        <EyebrowM dotColor="#3A5477">Compound Interest Calculator</EyebrowM>
        <div className="meta">
          €5,000 start · €200/mo<br />
          7% real return · <strong>30-year horizon</strong>
        </div>
      </div>

      <h1 className="headline">
        Same effort.<br />
        <em>Five times the result.</em>
      </h1>
      <div className="deck">
        What happens if you just leave the money alone — and let
        compounding do thirty years of quiet work.
      </div>

      <div className="chart-card">
        <div className="chart-head">
          <div>
            <div className="lbl">Projected value · year 30</div>
            <div className="val">€482,310</div>
          </div>
          <div className="legend">
            <span><span className="swatch" style={{ background: '#3A5477' }}></span>Invested</span>
            <span><span className="swatch" style={{ background: '#6E686A' }}></span>Cash savings</span>
          </div>
        </div>
        <CompoundChart />
        <div className="chart-foot">
          <span>2025</span>
          <span>2055</span>
        </div>
      </div>

      <div className="kpi-row">
        <div className="kpi">
          <div className="lbl">Contributed</div>
          <div className="val">€77K</div>
        </div>
        <div className="kpi">
          <div className="lbl">Cash savings</div>
          <div className="val">€77K</div>
        </div>
        <div className="kpi">
          <div className="lbl">Invested</div>
          <div className="val">€482K</div>
        </div>
      </div>

      <div className="footer">
        <FooterBrandM />
        <span className="cta-pill">Run the numbers →</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 10 — FIRE · Stacked App Cards
// ─────────────────────────────────────────────────────────────────────────
function Pin10() {
  return (
    <div className="pin pin-10">
      <div className="top">
        <EyebrowM dotColor="#C1D5A5">FIRE Calculator</EyebrowM>
      </div>
      <h1 className="headline">
        Three numbers in.<br />
        <em>One date out.</em>
      </h1>
      <div className="deck">
        The math behind financial independence is brutally simple. We built the
        calculator so you can stop pretending it's complicated.
      </div>

      <div className="stack">
        <div className="card c1">
          <div className="lbl">01 · Inputs</div>
          <div className="row"><span className="k">Annual income</span><span className="v">€72,000</span></div>
          <div className="row"><span className="k">Annual spend</span><span className="v">€36,400</span></div>
          <div className="row"><span className="k">Current age</span><span className="v">31</span></div>
        </div>
        <div className="card c2">
          <div className="lbl">02 · Calculated</div>
          <div className="row"><span className="k">Savings rate</span><span className="v">49%</span></div>
          <div className="row"><span className="k">FI target</span><span className="v">€910,000</span></div>
          <div className="row"><span className="k">Real return</span><span className="v">7%</span></div>
        </div>
        <div className="card c3">
          <div className="lbl">03 · Result</div>
          <div className="big">FI at <em>44</em></div>
          <div className="sub">13.2 years from today · 158 monthly contributions</div>
          <div className="chart-mini">
            <div className="b" style={{ height: '16%' }}></div>
            <div className="b" style={{ height: '22%' }}></div>
            <div className="b" style={{ height: '30%' }}></div>
            <div className="b" style={{ height: '38%' }}></div>
            <div className="b" style={{ height: '48%' }}></div>
            <div className="b" style={{ height: '60%' }}></div>
            <div className="b" style={{ height: '72%' }}></div>
            <div className="b" style={{ height: '85%' }}></div>
            <div className="b" style={{ height: '100%', background: '#47584F' }}></div>
          </div>
        </div>
      </div>

      <div className="footer">
        <FooterBrandM />
        <span className="cta-pill">Find your date →</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 11 — Save vs Invest · Side-by-side
// ─────────────────────────────────────────────────────────────────────────
function Pin11() {
  return (
    <div className="pin pin-11">
      <div className="top">
        <EyebrowM>Investing Calculator</EyebrowM>
      </div>
      <h1 className="headline">
        Same €500 a month.<br />
        <em>Wildly different ending.</em>
      </h1>
      <div className="deck">
        We ran €500/month for 25 years through two routes. The arithmetic of
        a high-yield savings account vs. a low-cost ETF.
      </div>

      <div className="compare">
        <div className="col left">
          <span className="role">Route A · Cash savings</span>
          <h3>Earn 2.5%</h3>
          <span className="nuance">Predictable. Liquid. Eroded by inflation.</span>

          <span className="after-label">After 25 years</span>
          <div className="amount">€207<em>K</em></div>

          <div className="delta">
            Contributed <strong>€150K</strong> · earned <strong>€57K</strong>
          </div>
        </div>
        <div className="col right">
          <span className="role">Route B · Index ETF</span>
          <h3>Earn 7%</h3>
          <span className="nuance">Volatile. Patient. Compounding.</span>

          <span className="after-label">After 25 years</span>
          <div className="amount">€406<em>K</em></div>

          <div className="delta">
            Contributed <strong>€150K</strong> · earned <strong>€256K</strong>
          </div>
        </div>
      </div>

      <div className="verdict">
        Same discipline. <strong>€199,000</strong> in compounding.
      </div>

      <div className="footer">
        <FooterBrandM />
        <span className="cta-pill">See the numbers →</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 12 — Salary → Wealth · Asymmetric Editorial
// ─────────────────────────────────────────────────────────────────────────
function Pin12() {
  return (
    <div className="pin pin-12">
      <div className="sage-block"></div>

      <div className="top">
        <EyebrowM>Lifetime Wealth Calculator</EyebrowM>
      </div>
      <h1 className="headline">
        What does a €60K salary <em>actually</em> buy you?
      </h1>
      <div className="deck">
        Over a forty-year career, a single salary moves more than two million
        euros through your life. The calculator shows where every chapter of
        it ends up — taxes, rent, food, future you.
      </div>

      <div className="sage-num">
        <div className="lbl">Lifetime through-flow</div>
        <div className="val">€2.4M</div>
        <div className="sub">Forty years · gross income</div>
      </div>

      <div className="breakdown">
        <div className="bcell">
          <div className="lbl">To tax</div>
          <div className="val">€680K</div>
        </div>
        <div className="bcell">
          <div className="lbl">To rent / home</div>
          <div className="val">€520K</div>
        </div>
        <div className="bcell">
          <div className="lbl">To living</div>
          <div className="val">€880K</div>
        </div>
        <div className="bcell">
          <div className="lbl">To future you</div>
          <div className="val">€320K</div>
        </div>
      </div>

      <div className="footer">
        <FooterBrandM />
        <span className="cta-pill">Map your career →</span>
      </div>
    </div>
  );
}

window.Pin9 = Pin9;
window.Pin10 = Pin10;
window.Pin11 = Pin11;
window.Pin12 = Pin12;
