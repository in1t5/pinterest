// Pins 5–8 — Pinterest pin templates (continued)

const LOGO_SRC_2 = 'assets/logo_framed.png';
const SITE_URL_2 = 'TIMEANDMONEYTREE.COM';

function Eyebrow5({ children, dotColor }) {
  return (
    <span className="eyebrow">
      <span className="dot" style={dotColor ? { background: dotColor } : null}></span>
      <span>{children}</span>
    </span>
  );
}
function FooterBrand5() {
  return (
    <div className="footer-brand">
      <img src={LOGO_SRC_2} alt="" />
      <div>
        <div className="name">Time &amp; Moneytree</div>
        <div className="url">{SITE_URL_2}</div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 5 — FI Age "47" · Big Number on navy
// ─────────────────────────────────────────────────────────────────────────
function Pin5() {
  return (
    <div className="pin pin-5">
      <div className="grid-bg"></div>

      <div className="top">
        <Eyebrow5 dotColor="#26C6DA">FIRE Calculator · Free</Eyebrow5>
        <span className="tag">— your number, in 60 seconds —</span>
      </div>

      <div className="question">
        At what age can you<br/>
        actually walk away?
      </div>

      <div className="big-num">47</div>

      <div className="answer-label">Your FI Age</div>

      <div className="inputs-row">
        <div className="input-cell">
          <div className="lbl">Take-home</div>
          <div className="val">€4,800<sup>/mo</sup></div>
        </div>
        <div className="input-cell">
          <div className="lbl">Save rate</div>
          <div className="val">38<sup>%</sup></div>
        </div>
        <div className="input-cell">
          <div className="lbl">Today</div>
          <div className="val">Age 31</div>
        </div>
      </div>

      <div className="deck">
        Based on a 7% real return and a 4% safe withdrawal rate — the same maths
        the early-retirement community has been stress-testing for thirty years.
      </div>

      <div className="footer">
        <FooterBrand5 />
        <span className="cta-pill">Find your age →</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 6 — ETF Tree · Illustrative on cream
// ─────────────────────────────────────────────────────────────────────────
function Pin6() {
  return (
    <div className="pin pin-6">
      <div className="top">
        <Eyebrow5>ETF Growth Calculator</Eyebrow5>
        <h1>
          Plant once.<br/>
          <em>Harvest for life.</em>
        </h1>
      </div>

      <div className="tree-wrap">
        <MoneyTreeSVG />
      </div>

      <div className="ground"></div>

      <div className="growth-strip">
        <div className="stage">
          <div className="yr">Year 1</div>
          <div className="amt">€10K</div>
        </div>
        <div className="grow"></div>
        <div className="stage">
          <div className="yr">Year 15</div>
          <div className="amt">€96K</div>
        </div>
        <div className="grow"></div>
        <div className="stage">
          <div className="yr">Year 30</div>
          <div className="amt big">€760K</div>
        </div>
      </div>

      <div className="tagline">
        One fund. One monthly transfer. Three decades of patience.
      </div>

      <div className="footer">
        <FooterBrand5 />
        <span className="cta-pill">Grow yours →</span>
      </div>
    </div>
  );
}

// Hand-drawn-feeling money tree — botanical with coin fruits
function MoneyTreeSVG() {
  return (
    <svg viewBox="0 0 620 620" xmlns="http://www.w3.org/2000/svg">
      {/* pot */}
      <path d="M210 520 L410 520 L390 600 L230 600 Z"
            fill="none" stroke="#47584F" strokeWidth="2.5" />
      <line x1="210" y1="540" x2="410" y2="540" stroke="#47584F" strokeWidth="1.5" />
      {/* soil */}
      <path d="M215 525 Q260 515 310 520 Q370 525 405 525"
            fill="none" stroke="#84A17C" strokeWidth="2" strokeLinecap="round" />

      {/* trunk */}
      <path d="M310 520 Q308 470 312 420 Q316 370 308 320 Q300 270 312 220 Q322 180 310 140"
            fill="none" stroke="#47584F" strokeWidth="3" strokeLinecap="round" />

      {/* main branches */}
      <path d="M311 360 Q260 340 220 290" fill="none" stroke="#47584F" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M311 320 Q360 300 400 260" fill="none" stroke="#47584F" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M310 250 Q270 220 240 180" fill="none" stroke="#47584F" strokeWidth="2.2" strokeLinecap="round" />
      <path d="M310 220 Q350 190 390 160" fill="none" stroke="#47584F" strokeWidth="2.2" strokeLinecap="round" />
      <path d="M310 160 Q300 130 290 100" fill="none" stroke="#47584F" strokeWidth="2.2" strokeLinecap="round" />
      <path d="M310 160 Q330 130 350 110" fill="none" stroke="#47584F" strokeWidth="2.2" strokeLinecap="round" />

      {/* leaves — sage clusters */}
      <g fill="#84A17C" opacity="0.92">
        <ellipse cx="220" cy="285" rx="44" ry="32" transform="rotate(-25 220 285)"/>
        <ellipse cx="180" cy="250" rx="38" ry="28" transform="rotate(-35 180 250)"/>
        <ellipse cx="395" cy="255" rx="44" ry="32" transform="rotate(25 395 255)"/>
        <ellipse cx="435" cy="225" rx="38" ry="28" transform="rotate(35 435 225)"/>
        <ellipse cx="240" cy="175" rx="38" ry="28" transform="rotate(-30 240 175)"/>
        <ellipse cx="390" cy="155" rx="38" ry="28" transform="rotate(30 390 155)"/>
        <ellipse cx="290" cy="95" rx="34" ry="26" transform="rotate(-15 290 95)"/>
        <ellipse cx="350" cy="105" rx="34" ry="26" transform="rotate(15 350 105)"/>
        <ellipse cx="320" cy="50" rx="36" ry="28" transform="rotate(0 320 50)"/>
      </g>

      {/* lighter leaves on top */}
      <g fill="#C1D5A5" opacity="0.85">
        <ellipse cx="205" cy="270" rx="22" ry="16" transform="rotate(-25 205 270)"/>
        <ellipse cx="170" cy="240" rx="20" ry="14" transform="rotate(-40 170 240)"/>
        <ellipse cx="412" cy="240" rx="22" ry="16" transform="rotate(30 412 240)"/>
        <ellipse cx="448" cy="218" rx="18" ry="14" transform="rotate(38 448 218)"/>
        <ellipse cx="227" cy="165" rx="20" ry="14" transform="rotate(-25 227 165)"/>
        <ellipse cx="405" cy="148" rx="20" ry="14" transform="rotate(30 405 148)"/>
        <ellipse cx="318" cy="38" rx="20" ry="14"/>
      </g>

      {/* coin "fruits" */}
      <g>
        <circle cx="195" cy="305" r="18" fill="#F5EEED" stroke="#F1683F" strokeWidth="2.5" />
        <text x="195" y="312" textAnchor="middle" fontFamily="Cormorant Garamond, serif"
              fontSize="22" fill="#F1683F" fontWeight="500">€</text>

        <circle cx="425" cy="275" r="18" fill="#F5EEED" stroke="#F1683F" strokeWidth="2.5" />
        <text x="425" y="282" textAnchor="middle" fontFamily="Cormorant Garamond, serif"
              fontSize="22" fill="#F1683F" fontWeight="500">€</text>

        <circle cx="265" cy="195" r="16" fill="#F5EEED" stroke="#F1683F" strokeWidth="2.5" />
        <text x="265" y="201" textAnchor="middle" fontFamily="Cormorant Garamond, serif"
              fontSize="20" fill="#F1683F" fontWeight="500">€</text>

        <circle cx="370" cy="175" r="16" fill="#F5EEED" stroke="#F1683F" strokeWidth="2.5" />
        <text x="370" y="181" textAnchor="middle" fontFamily="Cormorant Garamond, serif"
              fontSize="20" fill="#F1683F" fontWeight="500">€</text>

        <circle cx="305" cy="125" r="14" fill="#F5EEED" stroke="#F1683F" strokeWidth="2.5" />
        <text x="305" y="131" textAnchor="middle" fontFamily="Cormorant Garamond, serif"
              fontSize="18" fill="#F1683F" fontWeight="500">€</text>

        <circle cx="345" cy="75" r="14" fill="#F5EEED" stroke="#F1683F" strokeWidth="2.5" />
        <text x="345" y="81" textAnchor="middle" fontFamily="Cormorant Garamond, serif"
              fontSize="18" fill="#F1683F" fontWeight="500">€</text>
      </g>

      {/* small seedlings near pot */}
      <g stroke="#84A17C" strokeWidth="1.5" fill="none" strokeLinecap="round">
        <path d="M170 595 Q170 575 165 565" />
        <path d="M170 575 Q160 570 155 562" />
        <path d="M170 575 Q180 570 185 562" />
        <path d="M455 595 Q455 580 460 568" />
        <path d="M455 580 Q445 575 440 568" />
        <path d="M455 580 Q465 575 470 568" />
      </g>
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 7 — Mortgage · Editorial split
// ─────────────────────────────────────────────────────────────────────────
function Pin7() {
  return (
    <div className="pin pin-7">
      <div className="top">
        <Eyebrow5>Mortgage Payoff Calculator</Eyebrow5>
        <h1>
          Pay off the house.<br/>
          <em>Buy back your<br/>weekends.</em>
        </h1>
      </div>

      <div className="bottom">
        <div className="savings-card">
          <div className="cell">
            <div className="lbl">Years saved</div>
            <div className="val accent">8.4</div>
            <div className="sub">off a 30-year mortgage</div>
          </div>
          <div className="cell">
            <div className="lbl">Interest avoided</div>
            <div className="val">€74K</div>
            <div className="sub">that stays in your family</div>
          </div>
        </div>

        <div className="scenario">
          <svg className="arrow-svg" viewBox="0 0 60 24" fill="none">
            <path d="M2 12 L54 12 M44 4 L54 12 L44 20"
                  strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span>
            One extra <em>€350</em> a month — the price of a streaming
            bundle and a takeaway — and the mortgage ends nearly a decade early.
          </span>
        </div>

        <div className="footer">
          <FooterBrand5 />
          <span className="cta-pill">Try the calculator →</span>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 8 — Net Worth · Listicle on navy
// ─────────────────────────────────────────────────────────────────────────
function Pin8() {
  return (
    <div className="pin pin-8">
      <div className="grain"></div>

      <div className="top">
        <Eyebrow5 dotColor="#26C6DA">Net Worth Tracker</Eyebrow5>
        <h1>
          Your whole<br/>
          financial life<br/>
          in <em>four lines.</em>
        </h1>
      </div>

      <div className="ledger">
        <div className="row">
          <span className="n">01</span>
          <span className="label-col">
            <span className="k">What you own</span>
            <span className="sub">Cash · ETFs · home equity</span>
          </span>
          <span className="v positive">+ €312,000</span>
        </div>
        <div className="row">
          <span className="n">02</span>
          <span className="label-col">
            <span className="k">What you owe</span>
            <span className="sub">Mortgage · car · cards</span>
          </span>
          <span className="v negative">− €184,000</span>
        </div>
        <div className="row">
          <span className="n">03</span>
          <span className="label-col">
            <span className="k">Monthly flow</span>
            <span className="sub">In · out · saved</span>
          </span>
          <span className="v positive">+ €1,820</span>
        </div>
        <div className="row total-row">
          <span className="n">∑</span>
          <span className="label-col">
            <span className="k">Net worth</span>
          </span>
          <span className="v">€128,000</span>
        </div>
      </div>

      <div className="footer">
        <FooterBrand5 />
        <span className="cta-pill">Track yours →</span>
      </div>
    </div>
  );
}

window.Pin5 = Pin5;
window.Pin6 = Pin6;
window.Pin7 = Pin7;
window.Pin8 = Pin8;
