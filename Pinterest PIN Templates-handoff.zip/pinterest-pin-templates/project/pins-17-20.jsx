// Pins 17–20 — Fresh templates: timeline, receipt, postcard, botanical poster

const LOGO_F = 'assets/logo_framed.png';

function EyebrowF({ children, dotColor }) {
  return (
    <span className="eyebrow">
      <span className="dot" style={dotColor ? { background: dotColor } : null}></span>
      <span>{children}</span>
    </span>
  );
}
function FooterBrandF() {
  return (
    <div className="footer-brand">
      <img src={LOGO_F} alt="" />
      <div>
        <div className="name">Time &amp; Moneytree</div>
        <div className="url">TIMEANDMONEYTREE.COM</div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 17 — Path to FI · Timeline
// ─────────────────────────────────────────────────────────────────────────
function Pin17() {
  // Position nodes along the axis as percentages
  const nodes = [
    { pos: 5,  age: 30, kind: 'past' },
    { pos: 25, age: 34, kind: 'now',  milestone: 'Today',        val: '€42K',  note: 'starting point', up: true  },
    { pos: 45, age: 38, kind: 'past', milestone: 'Mortgage paid',val: '€186K', note: 'years saved · 6', up: false },
    { pos: 65, age: 42, kind: 'past', milestone: 'Coast FI',     val: '€420K', note: 'stop adding',     up: true  },
    { pos: 88, age: 45, kind: 'fi',   milestone: 'Full FI',      val: '€720K', note: 'walk-away day',   up: false },
  ];
  return (
    <div className="pin pin-17">
      <div className="topo"></div>

      <div className="top">
        <EyebrowF>FIRE Path Calculator</EyebrowF>
      </div>
      <h1 className="headline">
        From thirty-four<br />
        to <em>forty-five.</em>
      </h1>
      <div className="deck">
        Eleven years, four milestones, one slow line through the trees.
      </div>

      <div className="timeline">
        <div className="axis"></div>
        {nodes.map((n, i) => (
          <React.Fragment key={i}>
            <div className={`tnode ${n.kind}`} style={{ left: n.pos + '%' }}>
              <div className="dot"></div>
              <span className="age">{n.age}</span>
            </div>
            {n.milestone && (
              <div
                className={`callout ${n.up ? 'up' : 'down'}`}
                style={{ left: `calc(${n.pos}% - 90px)` }}
              >
                <div className="stub"></div>
                <div className="milestone">{n.milestone}</div>
                <div className="val">{n.val}</div>
                <div className="note">{n.note}</div>
              </div>
            )}
          </React.Fragment>
        ))}
      </div>

      <div className="footer">
        <FooterBrandF />
        <span className="cta-pill">Map your path →</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 18 — Monthly Budget · Receipt
// ─────────────────────────────────────────────────────────────────────────
function Pin18() {
  return (
    <div className="pin pin-18">
      <div className="top">
        <EyebrowF>Monthly Budget Calculator</EyebrowF>
      </div>
      <h1 className="headline">
        What a month <em>actually</em><br />
        costs us — line by line.
      </h1>

      <div className="receipt">
        <div className="r-head">
          <div className="biz">TIME &amp; MONEYTREE</div>
          <div className="sub">April 2025 · Family of 5 · No. 047</div>
        </div>

        <div className="r-section">Needs</div>
        <div className="r-row"><span className="lbl">Mortgage</span><span className="dots"></span><span className="amt">€780.00</span></div>
        <div className="r-row"><span className="lbl">Groceries</span><span className="dots"></span><span className="amt">€420.00</span></div>
        <div className="r-row"><span className="lbl">Utilities</span><span className="dots"></span><span className="amt">€140.00</span></div>
        <div className="r-row"><span className="lbl">Transport</span><span className="dots"></span><span className="amt">€90.00</span></div>
        <div className="r-row"><span className="lbl">Insurance</span><span className="dots"></span><span className="amt">€115.00</span></div>

        <div className="r-section">Wants</div>
        <div className="r-row"><span className="lbl">Coffee + dining</span><span className="dots"></span><span className="amt">€95.00</span></div>
        <div className="r-row"><span className="lbl">Kids' activities</span><span className="dots"></span><span className="amt">€180.00</span></div>
        <div className="r-row"><span className="lbl">Subscriptions</span><span className="dots"></span><span className="amt">€38.00</span></div>

        <div className="r-section">Future</div>
        <div className="r-row"><span className="lbl">ETF transfer</span><span className="dots"></span><span className="amt">€420.00</span></div>
        <div className="r-row"><span className="lbl">Buffer fund</span><span className="dots"></span><span className="amt">€62.00</span></div>

        <div className="r-total">
          <span className="lbl">Total</span>
          <span className="amt">€2,340</span>
        </div>

        <div className="r-foot">
          ── thank you for spending honestly ──
        </div>
      </div>

      <div className="footer">
        <FooterBrandF />
        <span className="cta-pill">Print your month →</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 19 — Postcard from Future You
// ─────────────────────────────────────────────────────────────────────────
function Pin19() {
  return (
    <div className="pin pin-19">
      <div className="top">
        <EyebrowF>Retirement Date Calculator</EyebrowF>
        <span className="tag">a postcard, sent backward</span>
      </div>
      <h1 className="headline">
        A note from <em>future you.</em>
      </h1>

      <div className="postcard">
        <div className="pc-left">
          <div className="greet">Hi, you —</div>
          <div className="note">
            It worked. The 7% return showed up.
            The boring decisions compounded. We bought
            back the weekends, then the weekdays.<br /><br />
            <strong>Eleven years. That's all it took.</strong><br /><br />
            Keep showing up. The maths is on our side.
          </div>
          <div className="signoff">
            — me, in 2037
            <small>postmarked from financial independence</small>
          </div>
        </div>

        <div className="divider"></div>

        <div className="pc-right">
          <div className="stamp">
            <span className="lbl">FI by</span>
            <span className="yr">2037</span>
            <span className="lbl">€720K</span>
          </div>
          <div className="postmark">
            POSTMARKED<br />
            AUG · 23 · 2037<br />
            FINANCIAL · INDEPENDENCE
          </div>

          <div className="pc-address">
            <div className="lead">To · younger you, c/o ·</div>
            <div className="line">The Family Of Five</div>
            <div className="line">A Modest House With Trees</div>
            <div className="line">Somewhere Patient · 2026</div>
          </div>
        </div>
      </div>

      <div className="footer">
        <FooterBrandF />
        <span className="cta-pill">Send yourself one →</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 20 — Botanical Poster · ETF Growth
// ─────────────────────────────────────────────────────────────────────────
function BotanicalSVG() {
  // Stylized vines/leaves framing a central composition
  return (
    <svg viewBox="0 0 1000 1500" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none">
      {/* Left vine */}
      <g stroke="#84A17C" strokeWidth="1.5" fill="none" strokeLinecap="round" opacity="0.7">
        <path d="M 90 1100 Q 60 950 100 800 Q 150 650 90 500 Q 60 380 100 280" />
        <path d="M 100 1000 Q 60 980 40 1010" />
        <path d="M 100 1000 Q 140 980 160 1010" />
        <path d="M 90 850 Q 50 830 30 860" />
        <path d="M 90 850 Q 130 830 150 860" />
        <path d="M 100 700 Q 60 680 40 710" />
        <path d="M 100 700 Q 140 680 160 710" />
        <path d="M 90 550 Q 50 530 30 560" />
        <path d="M 90 550 Q 130 530 150 560" />
        <path d="M 100 400 Q 60 380 40 410" />
        <path d="M 100 400 Q 140 380 160 410" />
      </g>
      {/* Left leaves */}
      <g fill="#84A17C" opacity="0.85">
        <ellipse cx="40" cy="1015" rx="22" ry="10" transform="rotate(-30 40 1015)" />
        <ellipse cx="160" cy="1015" rx="22" ry="10" transform="rotate(30 160 1015)" />
        <ellipse cx="30" cy="865" rx="20" ry="9" transform="rotate(-30 30 865)" />
        <ellipse cx="150" cy="865" rx="20" ry="9" transform="rotate(30 150 865)" />
        <ellipse cx="40" cy="715" rx="22" ry="10" transform="rotate(-30 40 715)" />
        <ellipse cx="160" cy="715" rx="22" ry="10" transform="rotate(30 160 715)" />
        <ellipse cx="30" cy="565" rx="20" ry="9" transform="rotate(-30 30 565)" />
        <ellipse cx="150" cy="565" rx="20" ry="9" transform="rotate(30 150 565)" />
        <ellipse cx="40" cy="415" rx="22" ry="10" transform="rotate(-30 40 415)" />
        <ellipse cx="160" cy="415" rx="22" ry="10" transform="rotate(30 160 415)" />
      </g>
      {/* Right vine (mirrored) */}
      <g stroke="#84A17C" strokeWidth="1.5" fill="none" strokeLinecap="round" opacity="0.7">
        <path d="M 910 1100 Q 940 950 900 800 Q 850 650 910 500 Q 940 380 900 280" />
        <path d="M 900 1000 Q 940 980 960 1010" />
        <path d="M 900 1000 Q 860 980 840 1010" />
        <path d="M 910 850 Q 950 830 970 860" />
        <path d="M 910 850 Q 870 830 850 860" />
        <path d="M 900 700 Q 940 680 960 710" />
        <path d="M 900 700 Q 860 680 840 710" />
        <path d="M 910 550 Q 950 530 970 560" />
        <path d="M 910 550 Q 870 530 850 560" />
        <path d="M 900 400 Q 940 380 960 410" />
        <path d="M 900 400 Q 860 380 840 410" />
      </g>
      <g fill="#84A17C" opacity="0.85">
        <ellipse cx="960" cy="1015" rx="22" ry="10" transform="rotate(30 960 1015)" />
        <ellipse cx="840" cy="1015" rx="22" ry="10" transform="rotate(-30 840 1015)" />
        <ellipse cx="970" cy="865" rx="20" ry="9" transform="rotate(30 970 865)" />
        <ellipse cx="850" cy="865" rx="20" ry="9" transform="rotate(-30 850 865)" />
        <ellipse cx="960" cy="715" rx="22" ry="10" transform="rotate(30 960 715)" />
        <ellipse cx="840" cy="715" rx="22" ry="10" transform="rotate(-30 840 715)" />
        <ellipse cx="970" cy="565" rx="20" ry="9" transform="rotate(30 970 565)" />
        <ellipse cx="850" cy="565" rx="20" ry="9" transform="rotate(-30 850 565)" />
        <ellipse cx="960" cy="415" rx="22" ry="10" transform="rotate(30 960 415)" />
        <ellipse cx="840" cy="415" rx="22" ry="10" transform="rotate(-30 840 415)" />
      </g>

      {/* Bottom curving branch with foliage circling under the big number */}
      <g stroke="#47584F" strokeWidth="2" fill="none" strokeLinecap="round" opacity="0.85">
        <path d="M 200 1080 Q 350 1040 500 1050 Q 650 1060 800 1080" />
      </g>
      <g fill="#84A17C">
        <ellipse cx="260" cy="1060" rx="22" ry="12" transform="rotate(-20 260 1060)" />
        <ellipse cx="320" cy="1048" rx="20" ry="10" transform="rotate(-10 320 1048)" />
        <ellipse cx="380" cy="1044" rx="18" ry="9" />
        <ellipse cx="500" cy="1042" rx="22" ry="12" />
        <ellipse cx="620" cy="1044" rx="18" ry="9" />
        <ellipse cx="680" cy="1048" rx="20" ry="10" transform="rotate(10 680 1048)" />
        <ellipse cx="740" cy="1060" rx="22" ry="12" transform="rotate(20 740 1060)" />
      </g>
      {/* Berries */}
      <g fill="#F1683F">
        <circle cx="270" cy="1085" r="6" />
        <circle cx="345" cy="1075" r="6" />
        <circle cx="655" cy="1075" r="6" />
        <circle cx="730" cy="1085" r="6" />
      </g>

      {/* Small frame line below center number area */}
      <line x1="380" y1="1110" x2="620" y2="1110" stroke="#47584F" strokeWidth="1" opacity="0.5" />
    </svg>
  );
}

function Pin20() {
  return (
    <div className="pin pin-20">
      <div className="botanical"><BotanicalSVG /></div>

      <div className="top">
        <EyebrowF>ETF Growth Calculator</EyebrowF>
      </div>
      <h1 className="headline">
        One fund.<br />
        One decision.<br />
        <em>Three decades.</em>
      </h1>

      <div className="center-num">
        <div className="lbl">After thirty patient years</div>
        <div className="val">€760K</div>
        <div className="sub">from €400 a month · global index · 7%</div>
      </div>

      <div className="seal">grown, not chased</div>

      <div className="footer">
        <FooterBrandF />
        <span className="cta-pill">Plant your money →</span>
      </div>
    </div>
  );
}

window.Pin17 = Pin17;
window.Pin18 = Pin18;
window.Pin19 = Pin19;
window.Pin20 = Pin20;
