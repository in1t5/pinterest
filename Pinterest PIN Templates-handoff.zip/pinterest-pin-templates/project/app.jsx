// app.jsx — design canvas hosting all 8 Pinterest pin templates

const PINS = [
  { id: 'pin-1', label: '01 · Big Number — Compound Interest', Comp: window.Pin1 },
  { id: 'pin-2', label: '02 · Editorial — Coast FI',          Comp: window.Pin2 },
  { id: 'pin-3', label: '03 · Pull Quote — Mindset',           Comp: window.Pin3 },
  { id: 'pin-4', label: '04 · Listicle — Five Numbers',        Comp: window.Pin4 },
  { id: 'pin-5', label: '05 · Big Number — FI Age',            Comp: window.Pin5 },
  { id: 'pin-6', label: '06 · Illustrative — ETF Tree',        Comp: window.Pin6 },
  { id: 'pin-7', label: '07 · Editorial Split — Mortgage',     Comp: window.Pin7 },
  { id: 'pin-8', label: '08 · Listicle — Net Worth',           Comp: window.Pin8 },
];

const PINS_MODERN = [
  { id: 'pin-9',  label: '09 · Chart Hero — Compound Interest', Comp: window.Pin9  },
  { id: 'pin-10', label: '10 · App Stack — FIRE Calculator',    Comp: window.Pin10 },
  { id: 'pin-11', label: '11 · Versus — Save vs Invest',        Comp: window.Pin11 },
  { id: 'pin-12', label: '12 · Asymmetric — Lifetime Wealth',   Comp: window.Pin12 },
  { id: 'pin-13', label: '13 · Probability Gauge — Withdrawal', Comp: window.Pin13 },
  { id: 'pin-14', label: '14 · Three Steps — FIRE Date',        Comp: window.Pin14 },
  { id: 'pin-15', label: '15 · KPI Dashboard — Money at a glance', Comp: window.Pin15 },
  { id: 'pin-16', label: '16 · Minimal Question — FI Number',   Comp: window.Pin16 },
];

const PINS_FRESH = [
  { id: 'pin-17', label: '17 · Timeline — Path to FI',           Comp: window.Pin17 },
  { id: 'pin-18', label: '18 · Receipt — Monthly Budget',        Comp: window.Pin18 },
  { id: 'pin-19', label: '19 · Postcard — From Future You',      Comp: window.Pin19 },
  { id: 'pin-20', label: '20 · Botanical Poster — ETF Growth',   Comp: window.Pin20 },
  { id: 'pin-21', label: '21 · Sticker Sheet — Money Rules',     Comp: window.Pin21 },
  { id: 'pin-22', label: '22 · Slow Horizon — Compound Sunrise', Comp: window.Pin22 },
  { id: 'pin-23', label: '23 · Passport Stamps — Milestones',    Comp: window.Pin23 },
  { id: 'pin-24', label: '24 · Index Cards — Three-card System', Comp: window.Pin24 },
];

const PINS_BATCH4 = [
  { id: 'pin-25', label: '25 · Newspaper — Front Page Story',    Comp: window.Pin25 },
  { id: 'pin-26', label: '26 · Planner Page — Sunday Ritual',    Comp: window.Pin26 },
  { id: 'pin-27', label: '27 · Bauhaus Grid — Modernist Blocks', Comp: window.Pin27 },
  { id: 'pin-28', label: '28 · Certificate — FI Diploma',        Comp: window.Pin28 },
  { id: 'pin-29', label: '29 · Type Specimen — One Glyph',       Comp: window.Pin29 },
  { id: 'pin-30', label: '30 · Polaroids — Net Worth Album',     Comp: window.Pin30 },
  { id: 'pin-31', label: '31 · Topographic Map — Route to FI',   Comp: window.Pin31 },
  { id: 'pin-32', label: '32 · Notebook — Handwritten Math',     Comp: window.Pin32 },
];

function App() {
  return (
    <DesignCanvas>
      <DCSection
        id="pins"
        title="Pinterest Pin Templates"
        subtitle="Eight reusable layouts · 1000×1500 · Time And Money Tree brand"
      >
        {PINS.map(({ id, label, Comp }) => (
          <DCArtboard key={id} id={id} label={label} width={1000} height={1500}>
            <Comp />
          </DCArtboard>
        ))}
      </DCSection>

      <DCSection
        id="pins-modern"
        title="Modern · Professional"
        subtitle="Eight more layouts · data-viz, dashboard tiles, side-by-side, gauges"
      >
        {PINS_MODERN.map(({ id, label, Comp }) => (
          <DCArtboard key={id} id={id} label={label} width={1000} height={1500}>
            <Comp />
          </DCArtboard>
        ))}
      </DCSection>

      <DCSection
        id="pins-fresh"
        title="Fresh metaphors"
        subtitle="Eight more · timeline, receipt, postcard, botanical, stickers, horizon, stamps, index cards"
      >
        {PINS_FRESH.map(({ id, label, Comp }) => (
          <DCArtboard key={id} id={id} label={label} width={1000} height={1500}>
            <Comp />
          </DCArtboard>
        ))}
      </DCSection>

      <DCSection
        id="pins-batch4"
        title="Editorial · Print · Specimen"
        subtitle="Eight more · newspaper, planner, modernist grid, certificate, type specimen, polaroids, map, notebook"
      >
        {PINS_BATCH4.map(({ id, label, Comp }) => (
          <DCArtboard key={id} id={id} label={label} width={1000} height={1500}>
            <Comp />
          </DCArtboard>
        ))}
      </DCSection>

      <DCSection
        id="notes"
        title="Notes"
        subtitle="A few thoughts on these templates"
      >
        <DCArtboard id="notes-1" label="System notes" width={520} height={520}>
          <div style={{
            padding: 36,
            height: '100%',
            background: '#F5EEED',
            fontFamily: 'Lato, sans-serif',
            color: '#1A1A18',
            lineHeight: 1.55,
            fontSize: 14,
          }}>
            <div style={{
              fontFamily: 'Cormorant Garamond, serif',
              fontWeight: 300,
              fontSize: 32,
              color: '#47584F',
              lineHeight: 1.05,
              marginBottom: 18,
              letterSpacing: '-0.01em',
            }}>
              How these templates work.
            </div>
            <p style={{ marginBottom: 12 }}>
              Each pin is a self-contained <code style={{
                background: '#EAEDCE', padding: '1px 6px', borderRadius: 4, fontSize: 13
              }}>.pin-N</code> block — copy one out as standalone HTML and
              every style comes with it.
            </p>
            <p style={{ marginBottom: 12 }}>
              Sizes are <strong>1000×1500</strong>, Pinterest's standard 2:3 ratio.
              Headlines use Cormorant Garamond; body and small caps use Lato — both
              from Google Fonts so exports stay faithful.
            </p>
            <p style={{ marginBottom: 12 }}>
              Six template families: <em>big number</em> (1, 5), <em>editorial
              magazine</em> (2, 7), <em>pull quote</em> (3), <em>numbered listicle</em>
              {' '}(4, 8), and <em>illustrative</em> (6). Mix and match per campaign.
            </p>
            <p style={{ color: '#6E686A' }}>
              Click any pin's header to <strong>open it fullscreen</strong> for a
              screenshot, or zoom in here for a quick comparison.
            </p>
          </div>
        </DCArtboard>

        <DCArtboard id="notes-2" label="Reusing as templates" width={520} height={520}>
          <div style={{
            padding: 36,
            height: '100%',
            background: '#47584F',
            color: '#F5EEED',
            fontFamily: 'Lato, sans-serif',
            fontSize: 14,
            lineHeight: 1.55,
          }}>
            <div style={{
              fontFamily: 'Cormorant Garamond, serif',
              fontWeight: 300,
              fontSize: 32,
              color: '#F5EEED',
              lineHeight: 1.05,
              marginBottom: 18,
              letterSpacing: '-0.01em',
            }}>
              Swapping content.
            </div>
            <ul style={{
              listStyle: 'none',
              padding: 0,
              margin: 0,
              display: 'flex',
              flexDirection: 'column',
              gap: 14,
            }}>
              <li>
                <strong style={{ color: '#C1D5A5' }}>Headlines</strong> —
                kept short (3–4 lines) so the serif can breathe. Use italic
                for the emphasis word.
              </li>
              <li>
                <strong style={{ color: '#C1D5A5' }}>Numbers</strong> —
                always in Cormorant Garamond. Keep ≤6 characters so they hit hard.
              </li>
              <li>
                <strong style={{ color: '#C1D5A5' }}>Calculator strips</strong> —
                mock 3 inputs at most. Real values, not lorem.
              </li>
              <li>
                <strong style={{ color: '#C1D5A5' }}>CTA</strong> — verb-first,
                ≤3 words. "Run the numbers", "Find your age", "Grow yours".
              </li>
              <li>
                <strong style={{ color: '#C1D5A5' }}>Footer URL</strong> — always
                timeandmoneytree.com in caps, with the framed logo.
              </li>
            </ul>
          </div>
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
