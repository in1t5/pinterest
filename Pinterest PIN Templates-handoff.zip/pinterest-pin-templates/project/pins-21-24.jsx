// Pins 21–24 — Fresh templates: stickers, horizon, stamps, index cards

const LOGO_F2 = 'assets/logo_framed.png';

function EyebrowF2({ children, dotColor }) {
  return (
    <span className="eyebrow">
      <span className="dot" style={dotColor ? { background: dotColor } : null}></span>
      <span>{children}</span>
    </span>
  );
}
function FooterBrandF2() {
  return (
    <div className="footer-brand">
      <img src={LOGO_F2} alt="" />
      <div>
        <div className="name">Time &amp; Moneytree</div>
        <div className="url">TIMEANDMONEYTREE.COM</div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 21 — Money Rules · Sticker sheet
// ─────────────────────────────────────────────────────────────────────────
function Pin21() {
  return (
    <div className="pin pin-21">
      <div className="grid-bg"></div>

      <div className="top">
        <EyebrowF2>Personal Finance Calculators</EyebrowF2>
      </div>
      <h1 className="headline">
        Seven rules that <em>do all the heavy lifting.</em>
      </h1>
      <div className="deck">
        Pin one above your desk. We made the calculator that does the maths
        behind each one.
      </div>

      <div className="sheet">
        <div className="sticker s1">
          <span className="num">01</span>
          <div className="rule">Pay future you <em>first.</em></div>
        </div>
        <div className="sticker s2">
          <span className="num">02</span>
          <div className="rule">Save 25%.</div>
        </div>
        <div className="sticker s3">
          <span className="num">03</span>
          <div className="rule">Index. <em>Don't gamble.</em></div>
        </div>
        <div className="sticker s4">
          <span className="num">04</span>
          <div className="rule">Buy time, <em>not stuff.</em></div>
        </div>
        <div className="sticker s5">
          <span className="num">05</span>
          <div className="rule">Annual spend <em>× 25</em> = freedom.</div>
        </div>
        <div className="sticker s6">
          <span className="num">06</span>
          <div className="rule">The 4% rule still works.</div>
        </div>
        <div className="sticker s7">
          <span className="num">07</span>
          <div className="rule">Boring is <em>the point.</em></div>
        </div>
      </div>

      <div className="footer">
        <FooterBrandF2 />
        <span className="cta-pill">Try the calculators →</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 22 — Slow Horizon · Atmospheric
// ─────────────────────────────────────────────────────────────────────────
function Pin22() {
  return (
    <div className="pin pin-22">
      <div className="top">
        <EyebrowF2>Compound Interest Calculator</EyebrowF2>
        <span className="tag">— a sunrise, not a sprint —</span>
      </div>

      <div className="quote">
        The slowest path<br />
        <em>is the fastest path.</em>
      </div>

      <div className="sun"></div>
      <div className="sun-disk"></div>

      <div className="horizon-line"></div>

      <div className="lower">
        <div className="lbl">Thirty quiet years</div>
        <div className="num">€482,310</div>
        <div className="sub">from €200 a month · 7% real return</div>
      </div>

      <div className="footer">
        <FooterBrandF2 />
        <span className="cta-pill">Set your horizon →</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 23 — Passport Stamps · Financial milestones
// ─────────────────────────────────────────────────────────────────────────
function Pin23() {
  return (
    <div className="pin pin-23">
      <div className="paper-noise"></div>

      <div className="top">
        <EyebrowF2>FIRE Milestone Calculator</EyebrowF2>
        <div className="meta">
          a passport for<br />
          your money
        </div>
      </div>

      <h1 className="headline">
        Stamps you earn<br />
        <em>one decade at a time.</em>
      </h1>
      <div className="deck">
        Six checkpoints on the path to financial independence — and the
        approximate age you'll hit each one.
      </div>

      <div className="stamps">
        <div className="stamp circle s23-1">
          <div className="ico">€10K</div>
          <div className="title">First Stash</div>
          <div className="yr">age 26</div>
        </div>
        <div className="stamp rect s23-2">
          <div className="title">No Bad Debt</div>
          <div className="yr">age 29</div>
        </div>
        <div className="stamp circle s23-3">
          <div className="ico">€100K</div>
          <div className="title">Six Figures</div>
          <div className="yr">age 33</div>
        </div>
        <div className="stamp rect s23-4">
          <div className="title">Mortgage Free</div>
          <div className="yr">age 39</div>
        </div>
        <div className="stamp circle s23-5">
          <div className="ico">Coast</div>
          <div className="title">Stop Adding</div>
          <div className="yr">age 42</div>
        </div>
        <div className="stamp rect s23-6">
          <div className="title">Full FI · 2038</div>
          <div className="yr">age 45</div>
        </div>
      </div>

      <div className="footer">
        <FooterBrandF2 />
        <span className="cta-pill">Stamp your passport →</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 24 — Index Cards · Three-card financial system
// ─────────────────────────────────────────────────────────────────────────
function Pin24() {
  return (
    <div className="pin pin-24">
      <div className="top">
        <EyebrowF2>The Whole System</EyebrowF2>
      </div>
      <h1 className="headline">
        Our money, on <em>three index cards.</em>
      </h1>
      <div className="deck">
        Personal finance fits on stationery. Everything else is decoration.
      </div>

      <div className="cards">
        <div className="icard ic1">
          <div className="hole"></div>
          <div className="label">CARD · 01 · EARN</div>
          <div className="title">Earn &amp; spend</div>
          <ul>
            <li>Spend less than €2,500 per month.</li>
            <li>Track once a week. Sunday morning.</li>
            <li>Pay every bill on autopay.</li>
          </ul>
          <div className="num"><small>Monthly spend</small>€2,340</div>
        </div>

        <div className="icard ic2">
          <div className="hole"></div>
          <div className="label">CARD · 02 · SAVE</div>
          <div className="title">Save &amp; invest</div>
          <ul>
            <li>€400 / mo into a global index ETF.</li>
            <li>Top up the buffer to six months' spend.</li>
            <li>Never touch the ETF. Ever.</li>
          </ul>
          <div className="num"><small>Save rate</small>38%</div>
        </div>

        <div className="icard ic3">
          <div className="hole"></div>
          <div className="label">CARD · 03 · WAIT</div>
          <div className="title">Wait &amp; live</div>
          <ul>
            <li>Don't check the balance more than monthly.</li>
            <li>Re-read these cards every January.</li>
            <li>That's the whole plan.</li>
          </ul>
          <div className="num"><small>FI date</small>2037</div>
        </div>
      </div>

      <div className="footer">
        <FooterBrandF2 />
        <span className="cta-pill">Get your cards →</span>
      </div>
    </div>
  );
}

window.Pin21 = Pin21;
window.Pin22 = Pin22;
window.Pin23 = Pin23;
window.Pin24 = Pin24;
