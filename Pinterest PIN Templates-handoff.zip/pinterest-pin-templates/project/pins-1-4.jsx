// Pins 1–4 — Pinterest pin templates
// Each is a self-contained 1000×1500 design block. All styles live in pins.css.

const LOGO_SRC = 'assets/logo_framed.png';
const SITE_URL = 'TIMEANDMONEYTREE.COM';

// ─────────────────────────────────────────────────────────────────────────
// Small helpers
// ─────────────────────────────────────────────────────────────────────────
function Eyebrow({ children, dotColor }) {
  return (
    <span className="eyebrow">
      <span className="dot" style={dotColor ? { background: dotColor } : null}></span>
      <span>{children}</span>
    </span>
  );
}

function FooterBrand({ name = 'Time & Moneytree', invert = false }) {
  return (
    <div className="footer-brand">
      <img src={LOGO_SRC} alt="" />
      <div>
        <div className="name">{name}</div>
        <div className="url">{SITE_URL}</div>
      </div>
    </div>
  );
}

function CTAPill({ label = 'Try it free', arrow = true }) {
  return (
    <span className="cta-pill">
      {label}
      {arrow && <span className="arrow">→</span>}
    </span>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 1 — Compound Interest · Big Number on cream
// ─────────────────────────────────────────────────────────────────────────
function Pin1() {
  return (
    <div className="pin pin-1">
      <div className="grid-paper"></div>

      <div className="top">
        <Eyebrow>Free Calculator · Compound Interest</Eyebrow>
        <div className="pretext">
          Start with <span>€5,000.</span><br/>
          Add <span>€200</span> a month.<br/>
          Wait <span>30 years.</span>
        </div>
        <div className="arrow-down">↓</div>
      </div>

      <div className="big-num">
        <span className="euro">€</span>482K
      </div>
      <div className="after">…the quietest €477,000 you'll ever earn.</div>
      <div className="underline"></div>

      <div className="calc-strip">
        <div className="calc-cell">
          <div className="lbl">Principal</div>
          <div className="val">€5,000</div>
        </div>
        <div className="calc-cell">
          <div className="lbl">Monthly</div>
          <div className="val">€200</div>
        </div>
        <div className="calc-cell">
          <div className="lbl">Return / yr</div>
          <div className="val">7%</div>
        </div>
      </div>

      <div className="tagline">
        Compounding does the work — <em>you just don't interrupt it.</em>
      </div>

      <div className="footer">
        <FooterBrand />
        <CTAPill label="Run the numbers" />
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 2 — Coast FI · Editorial / Magazine on cream
// ─────────────────────────────────────────────────────────────────────────
function Pin2() {
  return (
    <div className="pin pin-2">
      <div className="rule-top"></div>
      <div className="masthead">
        <span>Coast FI Calculator · Free</span>
        <span className="issue">No. 04 · Spring</span>
        <span>10-second answer</span>
      </div>

      <h1 className="headline">
        How much<br/>
        do you need<br/>
        to <em>stop saving?</em>
      </h1>

      <p className="deck">
        <span className="drop-cap">C</span>oast FI is the moment your investments
        can grow into a full retirement on their own — without you adding another
        euro. We built a calculator that tells you exactly when you've earned that
        permission.
      </p>

      <div className="preview-card">
        <div className="label">Coast FI Calculator</div>
        <div className="row">
          <span className="k">Current age</span>
          <span className="v">34</span>
        </div>
        <div className="row">
          <span className="k">Retire at</span>
          <span className="v">65</span>
        </div>
        <div className="row">
          <span className="k">Target nest egg</span>
          <span className="v">€780,000</span>
        </div>
        <div className="row result">
          <span className="k">Coast number today</span>
          <span className="v">€127,400</span>
        </div>
      </div>

      <div className="footer">
        <FooterBrand />
        <div className="cta-text">
          <span className="a">Find your coast number →</span>
          <span className="b">timeandmoneytree.com</span>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 3 — Mindset Pull-Quote · Forest green
// ─────────────────────────────────────────────────────────────────────────
function Pin3() {
  return (
    <div className="pin pin-3">
      <div className="grain"></div>
      <div className="ring"></div>
      <div className="ring-2"></div>

      <div className="top">
        <Eyebrow dotColor="#C1D5A5">A Note From The Tree</Eyebrow>
        <span className="pageno">— a family of five —</span>
      </div>

      <div className="quote-mark">"</div>
      <div className="quote">
        We didn't<br/>
        become rich.<br/>
        <em>We became free.</em>
      </div>

      <div className="signature">Anna &amp; Marc</div>
      <div className="credit">Founders · since 2019</div>

      <div className="freedom-link">
        Plan your freedom date
        <span className="arrow">→</span>
      </div>

      <div className="footer">
        <FooterBrand />
        <span style={{
          fontFamily: 'Cormorant Garamond, serif',
          fontStyle: 'italic',
          fontSize: 22,
          color: '#C1D5A5'
        }}>
          the tree doesn't rush its growth.
        </span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 4 — Five Numbers · Listicle on cream
// ─────────────────────────────────────────────────────────────────────────
function Pin4() {
  return (
    <div className="pin pin-4">
      <div className="topband">
        <Eyebrow>Free Budget Calculator</Eyebrow>
        <h1>
          Five numbers <em>every family</em><br/>
          should know by heart.
        </h1>
      </div>

      <div className="list">
        <div className="item">
          <div className="num">01</div>
          <div className="body">
            <div className="title">Monthly spend</div>
            <div className="desc">What an average month actually costs — groceries, rent, the small things you keep forgetting about.</div>
            <span className="pill">Ours: €2,340</span>
          </div>
        </div>
        <div className="item">
          <div className="num">02</div>
          <div className="body">
            <div className="title">Savings rate</div>
            <div className="desc">The single number that decides when you stop working. Aim for 25% before you optimize anything else.</div>
            <span className="pill">Target: 25%+</span>
          </div>
        </div>
        <div className="item">
          <div className="num">03</div>
          <div className="body">
            <div className="title">Emergency cushion</div>
            <div className="desc">Months of expenses sitting boring in a savings account. Boring is exactly the point.</div>
            <span className="pill">6 months</span>
          </div>
        </div>
        <div className="item">
          <div className="num">04</div>
          <div className="body">
            <div className="title">Annual ETF contribution</div>
            <div className="desc">One flat number, one fund, automated on the 1st. Calmer than any spreadsheet.</div>
            <span className="pill">€14,400/yr</span>
          </div>
        </div>
        <div className="item">
          <div className="num">05</div>
          <div className="body">
            <div className="title">Your FI number</div>
            <div className="desc">Annual spend × 25. The finish line — written down, not vaguely imagined.</div>
            <span className="pill">€702,000</span>
          </div>
        </div>
      </div>

      <div className="footer">
        <FooterBrand />
        <span className="cta-pill">Calculate yours →</span>
      </div>
    </div>
  );
}

window.Pin1 = Pin1;
window.Pin2 = Pin2;
window.Pin3 = Pin3;
window.Pin4 = Pin4;
