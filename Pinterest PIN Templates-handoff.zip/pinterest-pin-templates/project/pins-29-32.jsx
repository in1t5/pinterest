// Pins 29–32 — Type Specimen, Polaroids, Topographic Map, Notebook

const LOGO_G2 = 'assets/logo_framed.png';

function EyebrowG2({ children, dotColor }) {
  return (
    <span className="eyebrow">
      <span className="dot" style={dotColor ? { background: dotColor } : null}></span>
      <span>{children}</span>
    </span>
  );
}
function FooterBrandG2() {
  return (
    <div className="footer-brand">
      <img src={LOGO_G2} alt="" />
      <div>
        <div className="name">Time &amp; Moneytree</div>
        <div className="url">TIMEANDMONEYTREE.COM</div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 29 — Type Specimen Poster
// ─────────────────────────────────────────────────────────────────────────
function Pin29() {
  return (
    <div className="pin pin-29">
      <div className="top-rule">
        <span>Type · Specimen · 044</span>
        <span className="center">— compound interest, in one glyph —</span>
        <span>1000 × 1500 mm</span>
      </div>

      <div className="glyph">€</div>

      <div className="corners">
        <div className="c tl"></div>
        <div className="c tr"></div>
        <div className="c bl"></div>
        <div className="c br"></div>
      </div>

      <div className="center-label">The whole calculator, abbreviated</div>
      <h1 className="headline">
        Plant the euro.<br />
        <em>Let arithmetic do the rest.</em>
      </h1>

      <div className="scale">
        <span className="s1">€200/mo</span>
        <span className="s2">+ 7%</span>
        <span className="s3">× 30 yrs</span>
        <span className="s4">= €482K</span>
        <span className="s5">— our maths</span>
      </div>

      <div className="footer">
        <FooterBrandG2 />
        <span className="cta-pill">Calculate yours →</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 30 — Polaroids
// ─────────────────────────────────────────────────────────────────────────
function Pin30() {
  return (
    <div className="pin pin-30">
      <div className="canvas-grain"></div>
      <div className="top">
        <EyebrowG2>Net Worth Tracker</EyebrowG2>
        <div className="tag">our family album</div>
      </div>

      <h1 className="headline">
        Eleven years.<br />
        Five <em>snapshots.</em>
      </h1>

      <div className="album">
        <div className="polaroid p1">
          <div className="tape"></div>
          <div className="photo">
            <div>
              <span className="y">2014</span>
              <span className="v">€−8,200</span>
            </div>
          </div>
          <div className="caption">starting honest</div>
        </div>

        <div className="polaroid p2">
          <div className="tape"></div>
          <div className="photo">
            <div>
              <span className="y">2018</span>
              <span className="v">€38K</span>
            </div>
          </div>
          <div className="caption">first six figures, eventually</div>
        </div>

        <div className="polaroid p3">
          <div className="tape"></div>
          <div className="photo">
            <div>
              <span className="y">2021</span>
              <span className="v">€124K</span>
            </div>
          </div>
          <div className="caption">mortgage halved</div>
        </div>

        <div className="polaroid p4">
          <div className="tape"></div>
          <div className="photo">
            <div>
              <span className="y">2024</span>
              <span className="v">€296K</span>
            </div>
          </div>
          <div className="caption">compounding showed up</div>
        </div>

        <div className="polaroid p5">
          <div className="tape"></div>
          <div className="photo">
            <div>
              <span className="y">2025</span>
              <span className="v">€412K</span>
            </div>
          </div>
          <div className="caption">today — half-way home</div>
        </div>
      </div>

      <div className="footer">
        <FooterBrandG2 />
        <span className="cta-pill">Start your album →</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 31 — Topographic Map
// ─────────────────────────────────────────────────────────────────────────
function TopoMap() {
  // Concentric stylised contour lines + a route from bottom-left to top-right
  const rings = [];
  for (let i = 0; i < 12; i++) {
    const r = 80 + i * 60;
    rings.push(
      <ellipse key={i}
        cx="780" cy="380"
        rx={r * 1.2} ry={r * 0.9}
        fill="none"
        stroke="#47584F"
        strokeWidth="1"
        opacity={0.15 + (i % 3) * 0.05}
      />
    );
  }
  return (
    <svg viewBox="0 0 1000 1500" preserveAspectRatio="xMidYMid slice">
      {/* main mountain rings */}
      <g>{rings}</g>

      {/* small second mountain */}
      {[...Array(6)].map((_, i) => (
        <ellipse key={'b' + i}
          cx="240" cy="1080"
          rx={(40 + i * 28) * 1.3} ry={(40 + i * 28) * 0.7}
          fill="none" stroke="#84A17C" strokeWidth="1"
          opacity={0.18 + (i % 2) * 0.06}
        />
      ))}

      {/* route path */}
      <path
        d="M 130 1180 Q 240 1080 320 970 Q 380 880 420 800 Q 460 720 540 660 Q 620 600 700 520 Q 760 460 820 380"
        fill="none"
        stroke="#F1683F"
        strokeWidth="4"
        strokeDasharray="10 8"
        strokeLinecap="round"
      />
      {/* start marker */}
      <circle cx="130" cy="1180" r="14" fill="#F5EEED" stroke="#47584F" strokeWidth="3" />
      <circle cx="130" cy="1180" r="5" fill="#47584F" />
      {/* milestone markers */}
      <circle cx="320" cy="970" r="9" fill="#F1683F" stroke="#fff" strokeWidth="2" />
      <circle cx="540" cy="660" r="9" fill="#F1683F" stroke="#fff" strokeWidth="2" />
      <circle cx="700" cy="520" r="9" fill="#F1683F" stroke="#fff" strokeWidth="2" />
      {/* end / summit */}
      <g transform="translate(820 380)">
        <polygon points="0,-26 22,16 -22,16" fill="#47584F" />
        <polygon points="0,-26 22,16 0,8" fill="#84A17C" />
        <rect x="-3" y="-44" width="2" height="22" fill="#47584F" />
        <path d="M -1 -42 L 22 -38 L -1 -30 Z" fill="#F1683F" />
      </g>
    </svg>
  );
}

function Pin31() {
  return (
    <div className="pin pin-31">
      <div className="topo-bg"><TopoMap /></div>

      <div className="top">
        <EyebrowG2>FIRE Path Calculator</EyebrowG2>
        <div className="compass">N</div>
      </div>

      <h1 className="headline">
        The map from<br />
        <em>broke to free.</em>
      </h1>

      <div className="legend">
        <div className="lt">Map Legend</div>
        <div className="lr"><span className="dot start"></span><span>Start · today's balance</span></div>
        <div className="lr"><span className="dot mid"></span><span>Milestone · key checkpoint</span></div>
        <div className="lr"><span className="dot end"></span><span>Summit · financial independence</span></div>
      </div>

      <div className="waypoint" style={{ left: 310, top: 420 }}>
        <div className="wp-name">Base camp</div>
        <div className="wp-val">€0 · age 30</div>
      </div>
      <div className="waypoint" style={{ left: 320, top: 660 }}>
        <div className="wp-name">First plateau</div>
        <div className="wp-val">€100K · age 34</div>
      </div>
      <div className="waypoint" style={{ left: 540, top: 580 }}>
        <div className="wp-name">Coast FI</div>
        <div className="wp-val">€420K · age 41</div>
      </div>

      <div className="destination">
        <div className="lbl">Summit</div>
        <div className="name">€720K</div>
        <div className="meta">— age 44 · full FI —</div>
      </div>

      <div className="footer">
        <FooterBrandG2 />
        <span className="cta-pill">Plot your route →</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// PIN 32 — Notebook (handwritten math)
// ─────────────────────────────────────────────────────────────────────────
function Pin32() {
  return (
    <div className="pin pin-32">
      <div className="notebook"></div>
      <div className="margin-line"></div>

      <div className="top">
        <EyebrowG2>FIRE Number Calculator</EyebrowG2>
      </div>

      <h1 className="headline">
        The whole maths,<br />
        <em>on one page.</em>
      </h1>

      <div className="work">
        <div className="step-line">
          <span className="kk">monthly spend</span>
          <span className="vv">€2,340</span>
          <span className="annot">~ rent + food + life</span>
        </div>
        <div className="step-line">
          <span className="kk">× 12</span>
          <span className="vv">→ €28,080 / yr</span>
        </div>
        <div className="step-line">
          <span className="kk">× 25</span>
          <span className="vv">→ €702,000</span>
          <span className="annot">the 4% rule, basically</span>
        </div>
        <div className="equation-line">
          <span className="label">FI number = annual spend × 25</span>
          <span className="arrow">⤵</span>
        </div>
      </div>

      <div className="answer">
        <span className="label">therefore</span>
        <span className="val">€702K</span>
      </div>

      <div className="scribble">
        — that's all it is, really.
        <small>— a Sunday afternoon, 2026</small>
      </div>

      <div className="footer">
        <FooterBrandG2 />
        <span className="cta-pill">Show my work →</span>
      </div>
    </div>
  );
}

window.Pin29 = Pin29;
window.Pin30 = Pin30;
window.Pin31 = Pin31;
window.Pin32 = Pin32;
